package movieticketsalesapp;

public class MovieTicket {

    public boolean validateData(String movieName, int numTickets, double ticketPrice) {
        if (movieName == null || movieName.isEmpty()) {
            return false;
        }
        if (numTickets <= 0) {
            return false;
        }
        if (ticketPrice <= 0) {
            return false;
        }
        return true;
    }

    public double calculateTotal(double ticketPrice, int numTickets) {
        return ticketPrice * numTickets;
    }
}
