package movieticketsalesapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class MovieTicketApp {
    private JFrame frame;
    private JComboBox<String> movieComboBox;
    private JTextField ticketsField, priceField;
    private JTextArea reportArea;
    private MovieTickets movieTickets;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MovieTicketApp().initialize());
    }

    public void initialize() {
        movieTickets = new MovieTickets();
        
        frame = new JFrame("Movie Ticket Sales");
        frame.setLayout(new BorderLayout());
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu toolMenu = new JMenu("Tool");
        
        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");
        
        exitItem.addActionListener(e -> System.exit(0));
        processItem.addActionListener(e -> processTickets());
        clearItem.addActionListener(e -> clearFields());

        fileMenu.add(exitItem);
        toolMenu.add(processItem);
        toolMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolMenu);
        frame.setJMenuBar(menuBar);

        
        String[] movies = {"Napoleon", "Oppenheimer", "Damsel"};
        movieComboBox = new JComboBox<>(movies);
        movieComboBox.setSelectedIndex(0);

       
        ticketsField = new JTextField(10);
        priceField = new JTextField(10);

        
        reportArea = new JTextArea(10, 30);
        reportArea.setEditable(false);

      
        JPanel inputPanel = new JPanel();
        inputPanel.add(new JLabel("Select Movie:"));
        inputPanel.add(movieComboBox);
        inputPanel.add(new JLabel("No. of Tickets:"));
        inputPanel.add(ticketsField);
        inputPanel.add(new JLabel("Ticket Price:"));
        inputPanel.add(priceField);

        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(reportArea), BorderLayout.CENTER);
        
        frame.setVisible(true);
    }

    private void processTickets() {
        String selectedMovie = (String) movieComboBox.getSelectedItem();
        int numTickets;
        double ticketPrice;
        
        
        try {
            numTickets = Integer.parseInt(ticketsField.getText());
            ticketPrice = Double.parseDouble(priceField.getText());
            
            if (!movieTickets.validateData(selectedMovie, numTickets, ticketPrice)) {
                throw new Exception("Invalid input");
            }
            
            double totalPrice = movieTickets.calculateTotal(ticketPrice, numTickets);
            double vat = totalPrice * 0.14;
            double finalPrice = totalPrice + vat;

            String report = "Movie: " + selectedMovie + "\n"
                          + "Number of Tickets: " + numTickets + "\n"
                          + "Ticket Price: " + ticketPrice + "\n"
                          + "VAT (14%): " + vat + "\n"
                          + "Total: " + finalPrice + "\n";
            
            reportArea.setText(report);
            saveSalesReport(report);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Please enter valid data.");
        }
    }

    private void saveSalesReport(String report) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("movie_sales.txt", true))) {
            writer.write(report);
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving sales report.");
        }
    }

    private void clearFields() {
        movieComboBox.setSelectedIndex(0);
        ticketsField.setText("");
        priceField.setText("");
        reportArea.setText("");
    }
}
