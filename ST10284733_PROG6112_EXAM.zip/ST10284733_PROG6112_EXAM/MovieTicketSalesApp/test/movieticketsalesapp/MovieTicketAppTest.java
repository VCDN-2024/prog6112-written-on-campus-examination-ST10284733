import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MovieTicketsTest {

    private MovieTickets movieTickets;

    @BeforeEach
    public void setUp() {
        // Initialize the MovieTickets object before each test
        movieTickets = new MovieTickets();
    }

    // Test case for validating movie ticket data
    @Test
    public void testValidateData_ValidInput() {
        // Valid input
        boolean result = movieTickets.validateData("Napoleon", 5, 100.0);
        assertTrue(result, "Valid data should return true.");
    }

    @Test
    public void testValidateData_InvalidMovieName() {
        // Invalid movie name (empty string)
        boolean result = movieTickets.validateData("", 5, 100.0);
        assertFalse(result, "Movie name cannot be empty.");

        // Invalid movie name (null)
        result = movieTickets.validateData(null, 5, 100.0);
        assertFalse(result, "Movie name cannot be null.");
    }

    @Test
    public void testValidateData_InvalidNumberOfTickets() {
        // Invalid number of tickets (less than or equal to 0)
        boolean result = movieTickets.validateData("Napoleon", 0, 100.0);
        assertFalse(result, "Number of tickets must be greater than 0.");

        result = movieTickets.validateData("Napoleon", -5, 100.0);
        assertFalse(result, "Number of tickets must be greater than 0.");
    }

    @Test
    public void testValidateData_InvalidTicketPrice() {
        // Invalid ticket price (less than or equal to 0)
        boolean result = movieTickets.validateData("Napoleon", 5, 0.0);
        assertFalse(result, "Ticket price must be greater than 0.");

        result = movieTickets.validateData("Napoleon", 5, -50.0);
        assertFalse(result, "Ticket price must be greater than 0.");
    }

    // Test case for calculating total ticket price
    @Test
    public void testCalculateTotal() {
        // Valid input (with ticket price 100.0 and 5 tickets)
        double total = movieTickets.calculateTotal(100.0, 5);
        assertEquals(500.0, total, "Total ticket price should be 500.0.");
    }

    // Test case for calculating total with VAT (14%)
    @Test
    public void testCalculateTotalWithVAT() {
        // Valid input (with ticket price 100.0 and 5 tickets)
        double total = movieTickets.calculateTotal(100.0, 5);
        double vat = total * 0.14; // VAT is 14%
        double finalTotal = total + vat;

        assertEquals(570.0, finalTotal, "Total with VAT should be 570.0.");
    }

}
