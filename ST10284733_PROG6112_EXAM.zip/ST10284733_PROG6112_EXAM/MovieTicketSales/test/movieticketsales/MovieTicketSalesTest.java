
package movieticketsales;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MovieTicketSalesTest {

    @Test
    public void testTotalMovieSales() {
        // Create an instance of MovieTickets
        MovieTickets movieTickets = new MovieTickets();

        // Test case 1: Sales for "Napoleon"
        int[] napoleonSales = {3000, 1500, 1700}; 
        int napoleonTotal = movieTickets.TotalMovieSales(napoleonSales);
        assertEquals(5200, napoleonTotal, "Total sales for Napoleon should be 5200");

        // Test case 2: Sales for "Oppenheimer"
        int[] oppenheimerSales = {3500, 1200, 1600};
        int oppenheimerTotal = movieTickets.TotalMovieSales(oppenheimerSales);
        assertEquals(6300, oppenheimerTotal, "Total sales for Oppenheimer should be 6300");
    }

    @Test
    public void testTopMovie() {
        // Create an instance of MovieTickets
        MovieTickets movieTickets = new MovieTickets();

        // Movie names and their corresponding sales totals
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {5200, 6300};

        // Test case: Check the top-performing movie
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        assertEquals("Oppenheimer", topMovie, "The top movie should be Oppenheimer");
    }
    
    @Test
    public void testTopMovieWithEqualSales() {
        // Create an instance of MovieTickets
        MovieTickets movieTickets = new MovieTickets();

        // Test case where both movies have the same total sales
        String[] movies = {"Napoleon", "Oppenheimer"};
        int[] totalSales = {5000, 5000};

        // Since both have equal sales, it should return the first one
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        assertEquals("Napoleon", topMovie, "When sales are equal, the first movie should be returned");
    }

    @Test
    public void testTotalMovieSalesWithEmptyArray() {
        // Create an instance of MovieTickets
        MovieTickets movieTickets = new MovieTickets();

        // Test case: No sales
        int[] noSales = {};
        int total = movieTickets.TotalMovieSales(noSales);
        assertEquals(0, total, "Total sales for an empty array should be 0");
    }
}
