package movieticketsales;

public class MovieTickets {

   
    public int TotalMovieSales(int[] monthlySales) {
        int total = 0;
        for (int sale : monthlySales) {
            total += sale;
        }
        return total;
    }

   
    public String TopMovie(String[] movies, int[] totalSales) {
        int maxSales = totalSales[0];
        String topMovie = movies[0];
        
        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topMovie = movies[i];
            }
        }
        
        return topMovie;
    }
}
