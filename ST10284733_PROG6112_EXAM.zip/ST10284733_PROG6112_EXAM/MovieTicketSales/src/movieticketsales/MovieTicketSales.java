package movieticketsales;

public class MovieTicketSales {

    public static void main(String[] args) {
        
      
        String [] movies = {"Napoleon", "Oppenheimer"};
        
        int[][] movieSales = {
            {3000, 1500, 1700}, 
            {3500, 1200, 1600}   
        };
        
        
        MovieTickets movieTickets = new MovieTickets();
        
        
        int[] totalSales = new int[movies.length];
        
        
        for (int i = 0; i < movies.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(movieSales[i]);
        }
        
       
        System.out.println("Movie Sales Report for January - March 2024");
        
     
        for (int i = 0; i < movies.length; i++) {
            System.out.println(movies[i] + ": ");
            System.out.println("January: " + movieSales[i][0]);  
            System.out.println("February: " + movieSales[i][1]); 
            System.out.println("March: " + movieSales[i][2]);    
            System.out.println("Total Sales: " + totalSales[i]);
            System.out.println();
        }
        
        
        String topMovie = movieTickets.TopMovie(movies, totalSales);
        System.out.println("The top performing movie is: " + topMovie);
    }
}